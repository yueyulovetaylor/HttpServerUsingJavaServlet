package edu.upenn.cis455.webserver;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/*
 * This is the class dealing with the responses, it takes in the socket, directory,
 * and other information, and construct the suitable 
 * response and parse it to the socket.
 */

public class ResponseHandler {
	int threadNumber;
	Socket curSocket;
	SingleThreadHandler[] curThreadPoolList;
	BufferedReader in;				// Input stream from client side
	OutputStream outStream;
	DataOutputStream dataOutStream;
	String httpVersion;
	float httpVersionNo;
	String statusCodePhrase;
	String contentType;
	String curURL;
	String rootDirectory;
	
	final String DateTimeFormat = "EEE, d MMM yyyy HH:mm:ss Z";
	final SimpleDateFormat sdfFormat = new SimpleDateFormat(DateTimeFormat);		
	// Rererence: https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html
	Calendar cal = Calendar.getInstance();
	String curTime;
	
	int contentLength;
	boolean isHost;
	boolean isIfModified;
	boolean isIfUnmodified;
	
	String sInputModifiedDate;
	long lInputModifiedDate;   		// Representing the modified or unmodified date
	boolean toShutDown;				// Whether to shut down the server
	
	
	public ResponseHandler(int inputThreadNumber,
					       Socket inputSocket,
					       SingleThreadHandler[] inputThreadPoolList,
					       String inputRootDirectory,
					       DaemonThread inputDT) throws IOException {
		this.threadNumber = inputThreadNumber;
		System.out.println("---- ResponseHandler:ResponseHandler() Entering: Thread " + this.threadNumber);
		
		this.curSocket = inputSocket;
		this.curThreadPoolList = inputThreadPoolList;
		this.in = new BufferedReader(
				  new InputStreamReader(curSocket.getInputStream()));
		this.outStream = curSocket.getOutputStream();
		this.dataOutStream = new DataOutputStream(outStream);
		this.isHost = false;  		// Initialized as false, waiting for Host: to flip
		this.isIfModified = false;
		this.isIfUnmodified = false;
		this.rootDirectory = inputRootDirectory;
		
		System.out.println("---- ResponseHandler:ResponseHandler() Exiting: Thread " + this.threadNumber);
	}
	
	public void processHttpRequest() throws IOException {
		System.out.println("---- ResponseHandler:processHttpRequest() Entering: Thread " + this.threadNumber);
		
		// Get the Http Request from the client and split them into different parts: command,
		// URL, Http version
		String httpRequest = in.readLine();
		System.out.println("---- ResponseHandler:processHttpRequest() Request: " + httpRequest + " Thread " + this.threadNumber);
		String[] httpRequestSplits = httpRequest.split("\\s+");
		
		String command = httpRequestSplits[0].trim();
//		System.out.println("---- ResponseHandler:processHttpRequest() command: \"" + command + "\"");
		this.curURL = httpRequestSplits[1].trim();
		this.httpVersion = httpRequestSplits[2].trim();
		httpVersionNo = Float.parseFloat(httpVersion.substring(5));
		
		if (!command.equals("GET") && !command.equals("HEAD")) {
			// Our Http server only needs to support GET and HEAD methods, all others are illegal
			// It is a quick return situation, illegal method, 
			// Put this string on the webpage will be fine "HTTP/1.x 501 Not Implemented"
			System.out.println("---- ResponseHandler:processHttpRequest() Illegal method name: Thread " + this.threadNumber);
			this.statusCodePhrase = "501 NOT IMPLEMENTED";
			
			String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": UNDEFINED METHOD");
			
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		// Deal with URL now: URL Format: [path]?[fields:value]
		String curURLWithoutField;
		int PosQuesMark = curURL.indexOf('?');
		if (PosQuesMark == -1) {
			curURLWithoutField = curURL.substring(1);
		}
		
		else {
			curURLWithoutField = curURL.substring(1, PosQuesMark);
		}
		
		// Detect if there are another input here, (used for HTTP/1.1 or If-Modified-Since)
		String hostModified;
		while (!(hostModified = in.readLine()).equals("")) {
			// There is a second line indicating hosting
//			System.out.println("---- ResponseHandler:processHttpRequest() readin: " + hostModified);
			String[] hostModifiedSplits = hostModified.split("\\s+");
//			System.out.println("---- ResponseHandler:processHttpRequest() command: " + hostModifiedSplits[0]);
			
			if (hostModifiedSplits[0].trim().equals("Host:")) {
				System.out.println("---- ResponseHandler:processHttpRequest() HOSTED");
				this.isHost = true;
			}
			
			else if (hostModifiedSplits[0].trim().equals("If-Modified-Since:")
				  || hostModifiedSplits[0].trim().equals("If-Unmodified-Since:")) {
				// Flip one of them
				if (hostModifiedSplits[0].trim().equals("If-Modified-Since:")) {
					System.out.println("---- ResponseHandler:processHttpRequest() MODIFIED");
					this.isIfModified = true;
				}
				
				if (hostModifiedSplits[0].trim().equals("If-Unmodified-Since:")) {
					System.out.println("---- ResponseHandler:processHttpRequest() UNMODIFIED");
					this.isIfUnmodified = true;
				}
				
				this.sInputModifiedDate = hostModified.substring(hostModifiedSplits[0].length() + 1);
										// Don't forget to skip the blank space
				
				try {
					this.lInputModifiedDate = sdfFormat.parse(this.sInputModifiedDate).getTime();
				} 
				
				catch (ParseException e) {
					System.out.println("---- ResponseHandler:processHttpRequest() Illegal (un)modified time format: Thread " + this.threadNumber);
					this.statusCodePhrase = "500 INTERNAL SERVER ERROR";
					
					String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": ILLEGAL (UN)MODIFIED TIME FORMAT");
					
					this.contentType = "text/html";
					this.curTime = sdfFormat.format(cal.getTime());
					this.contentLength = headerHTML.length();
					
					String responseStr = constructResponseStr();
					
					dataOutStream.writeBytes(responseStr);
					dataOutStream.writeBytes(headerHTML);
					return;
				}
			}
		}
		
		// If http version is 1.1, but there is no header parsed in; it's a bad request
		// Float.compare(f1, f2) return an integer, if positive, f1 > f2; if zero, f1 = f2; if negative, f1 < f2
		if (Float.compare(httpVersionNo, (float) 1.1) == 0 && !this.isHost) {
			System.out.println("---- ResponseHandler:processHttpRequest() HTTP1.1 require Host: Thread " + this.threadNumber);
			this.statusCodePhrase = "400 BAD REQUEST";
			
			String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": HTTP1.1 REQUIRE HOST");
			
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		// If curURLWithoutField = "/shutdown"
		if (curURLWithoutField.equals("shutdown")) {
			this.toShutDown = true;
			System.out.println("---- ResponseHandler:processHttpRequest(): to Shut Down server: Thread " + this.threadNumber);
			this.statusCodePhrase = "200 OK";
			
			String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": SHUT DOWN SERVER");
			
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		// If curURLWithoutField = "/control"
		if (curURLWithoutField.equals("control")) {
			System.out.println("---- ResponseHandler:processHttpRequest() to Show control");
			this.statusCodePhrase = "200 OK";
			
			// Construct name and seas login
			StringBuilder sbControl = new StringBuilder();
			sbControl.append("<h1>Name: Yue Yu; SEAS Login: yueyu</h1>");
			
			// Parsing all related Thread information
			SingleThreadHandler[] threadPool = this.curThreadPoolList;
			for (int i = 0; i < threadPool.length; i++) {
				sbControl.append("<p>Thread No. " + i + ": State: " + threadPool[i].getState().toString());
				if (threadPool[i].getState() == Thread.State.RUNNABLE) {
					// If is runnable we need to add the URL
					sbControl.append("; URL: " + threadPool[i].curRH.curURL);
				}
				sbControl.append("</p>");
			}
			
			// Append shut down button
			sbControl.append("<a href=\"/shutdown\"><button type=\"button\">Shutdown</button></a>");
			
			String headerHTML = sbControl.toString();
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		// At this place, we need to open the directory to get all the files
//		System.out.println("---- ResponseHandler:processHttpRequest() Open directory/file: Thread " + this.threadNumber);
		String completeURL = this.rootDirectory + this.curURL;
		System.out.println("---- ResponseHandler:processHttpRequest() Open directory/file: " + completeURL + " in Thread " + this.threadNumber);
		Path curPaths = Paths.get(completeURL);
		
		// Verifying the Existence of a File or Directory
		if (!Files.exists(curPaths)) {
			// If curPaths does not exist, not found!
			System.out.println("---- ResponseHandler:processHttpRequest() Path doesn't exist: Thread " + this.threadNumber);
			this.statusCodePhrase = "404 NOT FOUND";
			
			String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": ILLEGAL PATH");
			
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		File curFile = new File(curPaths.toString());
		String toCheckIfGetParentRoot = curFile.getCanonicalPath();
		
		if (toCheckIfGetParentRoot.indexOf(this.rootDirectory) == -1) {
			// If we cannot find rootDirectory inside toCheckIfGetParentRoot, which means 
			// rootDirectory is not parent of toCheckIfGetParentRoot, Forbid to visit
			System.out.println("---- ResponseHandler:processHttpRequest() Path is forbidden: Thread " + this.threadNumber);
			this.statusCodePhrase = "403 FORBIDDEN";
			
			String headerHTML = constructHtmlHeader(this.statusCodePhrase + ": CANNOT VISIT PARENT PATH");
			
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		// Modified and unmodified situation
		if (this.httpVersionNo == (float) 1.1) {
			long fileLastModified = curFile.lastModified();
			if (this.isIfModified && fileLastModified < this.lInputModifiedDate) {
				// "IF-MODIFIED-SINCE" Situation: if no modified
				System.out.println("---- ResponseHandler:processHttpRequest() isIfModified violation: Thread " + this.threadNumber);
				String isIfModifiedViolationResponse = 
						"HTTP/1.1 304 Not MOdified \n" +
						"Date: " + this.sInputModifiedDate + "\n";
				dataOutStream.writeBytes(isIfModifiedViolationResponse);
				return;	
			}
			
			if (this.isIfUnmodified && fileLastModified > this.lInputModifiedDate) {
				// "IF-UNMODIFIED-SINCE" Situation
				// "IF-MODIFIED-SINCE" Situation: if no modified
				System.out.println("---- ResponseHandler:processHttpRequest() isIfUnmodified violation: Thread " + this.threadNumber);
				String isIfModifiedViolationResponse = 
						"HTTP/1.1 412 Precondition Failed \n";
				dataOutStream.writeBytes(isIfModifiedViolationResponse);
				return;	
			}
		}
		
		if (curFile.isDirectory()) {
			// Directory output to web page (in firefox)
			System.out.println("---- ResponseHandler:processHttpRequest() Output Directory: Thread " + this.threadNumber);
			
			File[] fileList = curFile.listFiles();
			StringBuilder sbDirectory = new StringBuilder();
			sbDirectory.append("<h1>File List under: " + toCheckIfGetParentRoot + "</h1>");	// We use canonical Path, which is preferred
			
//			System.out.println("---- ResponseHandler:processHttpRequest() curURL: " + this.curURL + " Thread " + this.threadNumber);
			System.out.println("---- ResponseHandler:processHttpRequest() curURL: " + this.curURL);
			
			for (int i = 0; i < fileList.length; i++) {
				// Two situations here,  for href purpose, 1. if it's not root directory; 2. it is root directory
				// If combined together, will cause an error
				if (!this.curURL.equals("/")) {
					sbDirectory.append("<p><a href=\"" + this.curURL + "/" + fileList[i].getName() 
							+ "\">" + fileList[i].getName().toString() + "</a></p>");
				}
				
				else {
					sbDirectory.append("<p><a href=\"/" + fileList[i].getName() 
							+ "\">" + fileList[i].getName().toString() + "</a></p>");
				}
			}
			
			String headerHTML = sbDirectory.toString();
			this.statusCodePhrase = "200 OK";
			this.contentType = "text/html";
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = headerHTML.length();
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			dataOutStream.writeBytes(headerHTML);
			return;
		}
		
		else {
			// Pure File output to web page (in firefox)
			System.out.println("---- ResponseHandler:processHttpRequest() Output File: Thread " + this.threadNumber);
			
			// Read file into an InputStream and output to a ByteStreamOutput
			InputStream fileIn = new FileInputStream(curFile);
			ByteArrayOutputStream fileOutBytesStream = new ByteArrayOutputStream();
			int b;
			while ((b = fileIn.read()) != -1) {
				fileOutBytesStream.write(b);
			}
			
			byte[] outputInByteArray = fileOutBytesStream.toByteArray();
			
			// For the type, we will need the file's extension and return the correct type
			String curExtension = completeURL.substring(completeURL.lastIndexOf('.') + 1);
			this.statusCodePhrase = "200 OK";
			this.contentType = getFileType(curExtension);
			this.curTime = sdfFormat.format(cal.getTime());
			this.contentLength = outputInByteArray.length;
			
			String responseStr = constructResponseStr();
			
			dataOutStream.writeBytes(responseStr);
			if (command.equals("GET")) {
				dataOutStream.write(outputInByteArray);
			}
		}
		
		System.out.println("---- ResponseHandler:processHttpRequest() Exiting: Thread " + this.threadNumber);
	}
	
	public boolean getIfToShutDown() {
		return this.toShutDown;
	}
	
	public String getURL() {
		return this.curURL;
	}
	
	private String constructHtmlHeader(String headerString) {
		return "<html><h2>" + headerString + "</h2></html>";
	}
	
	private String constructResponseStr() {
		String result = this.httpVersion + " " + this.statusCodePhrase + "\n"
				      + "Content-type: " + this.contentType + "\n"
				      + "Date: " + this.curTime + "\n" 
				      + "content-length: " + this.contentLength + "\n"
				      + "Server: HTTP Server" + "\n\n";
		return result;
	}
	
	private String getFileType(String extension) {
		switch(extension) {
			case "txt": {
				return "text/plain";
			}
			case "html": {
				return "text/html";
			}
			case "jpg": {
				return "image/jpeg";
			}
			case "png": {
				return "image/png";
			}
			case "gif": {
				return "image/gif";
			}
			default: return "";
		}
	}
}
