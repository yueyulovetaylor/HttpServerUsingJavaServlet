package edu.upenn.cis455.webserver;

class HttpServer {
	public static void main(String args[]) throws InterruptedException {
		// There are two quick return situations here: 
		// 1. if no commands parsed in, print full name and SEAS login name; 
		// 2. if two or three commands, the first one is port to listen for 
		// connection, and root directory of the static web pages; 
		// TODO: The third parameter will be implemented in Milestone 2
		System.out.println("- HttpServer.main() entering");
		
		if (args.length < 2) {
			System.out.println("*** Author: Yue Yu (yueyu), exit!");
			return;
		}
		
		int portNumber = Integer.parseInt(args[0]);
		String directory = args[1];
		
		DaemonThread curDT = new DaemonThread(portNumber, directory);
		
		curDT.start();
		
		try {
			curDT.join();
		} catch (InterruptedException e) {
			System.out.println("HttpServer.main() Current Thread cannot be initiated.");
			e.printStackTrace();
		}
	}
  
}
