package edu.upenn.cis455.webserver;

import java.io.IOException;
import java.net.Socket;
import java.util.Queue;

/*
 * This class is just a transition class, it represents for one single thread,
 * while do nothing with dealing with the thread, i.e. deal with the http request
 * parsed into the socket
 */

public class SingleThreadHandler extends Thread {

	String directory;
	Queue<Socket> socketQueue;
	int threadNumber;			// Will be deleted in the end
	DaemonThread daemonThread;
	boolean isRunning;
	Socket toParse;
	SingleThreadHandler[] curTPList;
	ResponseHandler curRH;
	
	public SingleThreadHandler(String inputDirectory, 
							   Queue<Socket> inputSocketQueue,
							   DaemonThread inputDaemonThread,
							   SingleThreadHandler[] inputThreadPoolList,
							   int inputThreadNumber) {
		this.threadNumber = inputThreadNumber;
		System.out.println("--- SingleThreadHandler:SingleThreadHandler() Entering: thread No." + this.threadNumber);
		
		this.directory = inputDirectory;
		this.socketQueue = inputSocketQueue;
		this.daemonThread = inputDaemonThread;
		this.curTPList = inputThreadPoolList;
		this.isRunning = true;
		
		System.out.println("--- SingleThreadHandler:SingleThreadHandler() Exiting: thread No." + this.threadNumber);
	}
	
	public void run() {
		System.out.println("--- SingleThreadHandler:run() Entering: thread No." + this.threadNumber);	
		
		while (isRunning) {
			try {
				// Get one socket from the queue and parse into the lower level classes
				toParse = ReadSocketFromQueue();
				if (toParse == null) {
					System.out.println("--- SingleThreadHandler:run() Error: No Socket read from the queue thread No." + this.threadNumber);	
					return;
				}
				
				// We start to deal with the socket at this place 
				this.curRH = new ResponseHandler(this.threadNumber, 
						toParse, this.curTPList, this.directory, this.daemonThread);
				this.curRH.processHttpRequest();
				
				if (this.curRH.getIfToShutDown()) {
					this.daemonThread.shutDown();
					System.out.println("--- SingleThreadHandler:run() isRunning: " + this.isRunning);
					return;
				}
				
			} 
			
			catch (InterruptedException e) {
				System.out.println("--- SingleThreadHandler:run() Error1: ReadSocketFromQueue Error thread No." + this.threadNumber);
				e.printStackTrace();
				return;
			} 
			
			catch (IOException e) {
				System.out.println("--- SingleThreadHandler:run() Error2: ReadSocketFromQueue Error thread No." + this.threadNumber);
				e.printStackTrace();
			}
			
			finally {
				if (toParse != null) {
					try {
						toParse.close();
					} catch (IOException e) {
						System.out.println("--- SingleThreadHandler:run() Error: Unable to close socket thread No." + this.threadNumber);
						e.printStackTrace();
					}
				}
			}
		}
		
	}
	
	public Socket ReadSocketFromQueue() throws InterruptedException {
		synchronized (socketQueue) {
			System.out.println("--- SingleThreadHandler:ReadSocketFromQueue() Entering");
			// Synchronized socketQueue first before pop anything out of it
			System.out.println("--- SingleThreadHandler:ReadSocketFromQueue() thread No.:" + this.threadNumber + " Queue empty?" + socketQueue.isEmpty());
			while (socketQueue.isEmpty() && this.isRunning) {
				System.out.println(socketQueue.toString());
				if (!this.isRunning) return null;
				// Just wait until something get into the socket
				System.out.println("--- SingleThreadHandler:ReadSocketFromQueue() Queue waiting Thread No." + this.threadNumber);
				socketQueue.wait();	
			}
			
			// When we had something in the queue, don't forget to notify all 
			// before return the retrieved socket
			Socket toReturn = socketQueue.poll();
			
			System.out.println("--- SingleThreadHandler:ReadSocketFromQueue() Exiting");
			socketQueue.notifyAll();
			return toReturn;	
		}
	}
	
	public void closeCurrentThread() {
		this.isRunning = false;
	}
}
